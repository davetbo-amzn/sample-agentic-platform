import json
import os

def handler(event, context):
    """
    Pre-signup trigger to validate email domains
    """
    allowed_domains = os.environ.get('ALLOWED_EMAIL_DOMAINS', '').split(',')
    
    # If no domains specified, allow all
    if not allowed_domains or allowed_domains == ['']:
        return event
    
    email = event['request']['userAttributes'].get('email', '')
    email_domain = email.split('@')[-1] if '@' in email else ''
    
    if email_domain not in allowed_domains:
        raise Exception(f"Email domain {email_domain} is not allowed")
    
    return event
