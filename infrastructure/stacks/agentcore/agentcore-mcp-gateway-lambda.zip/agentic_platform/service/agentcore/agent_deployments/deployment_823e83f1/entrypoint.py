import os
import logging

from pydantic import BaseModel
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent
from strands.session.s3_session_manager import S3SessionManager
from strands.tools import agentic_web_browser_tool
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
from typing import Optional
from uuid import uuid4


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Environment: {os.environ}")

app = BedrockAgentCoreApp()

agent = Agent(tools=[agentic_web_browser_tool])

def generate_visualization(df, analysis_type):
    plt.figure(figsize=(10, 6))
    if analysis_type == "histogram":
        sns.histplot(data=df)
    elif analysis_type == "scatter":
        sns.scatterplot(data=df)
    elif analysis_type == "boxplot":
        sns.boxplot(data=df)
    else:
        sns.heatmap(df.corr(), annot=True)
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    plt.close()
    return base64.b64encode(buf.getvalue()).decode()




class HandlerRequest(BaseModel):
    prompt: str
    data_url: Optional[str] = None
    analysis_type: Optional[str] = None

class HandlerResponse(BaseModel):
    statusCode: int
    result: str
    visualization: Optional[str] = None


@app.entrypoint
def handler(evt) -> HandlerResponse:
    # Create a session manager that stores data in S3
    logger.info(f"handler received request {evt}, type {type(evt)}")
    request = evt
    if isinstance(request, dict):
        # not sure why it was coming in as a dict...
        logger.info(f"Converting request to HandlerRequest")
        request = HandlerRequest(prompt=request['prompt'])
        logger.info(f"Type is now {type(request)}")
    logger.info(f"Handler got request {request}")
    
    session_id = uuid4().hex
    result = agent(request.prompt, session_id=session_id)
    
    visualization = None
    if request.data_url:
        try:
            df = pd.read_csv(request.data_url)
            visualization = generate_visualization(df, request.analysis_type or "correlation")
        except Exception as e:
            logger.error(f"Error generating visualization: {e}")
    
    logger.info(f"returning result {result}, type {type(result)}")
    response_text = result.message['content'][0]['text']
    
    return HandlerResponse(
        statusCode=200,
        result=response_text,
        visualization=visualization
    ).__dict__


if __name__ == "__main__":
    logger.info('starting app')
    app.run()
    logger.info('exiting')
