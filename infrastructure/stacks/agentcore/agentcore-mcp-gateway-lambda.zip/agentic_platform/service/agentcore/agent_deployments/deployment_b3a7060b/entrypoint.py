import os
import logging

from pydantic import BaseModel
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent
from strands.session.s3_session_manager import S3SessionManager
from strands.tools.agentic_web_browser_tool import AWebBrowserTool
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
from uuid import uuid4


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Environment: {os.environ}")


app = BedrockAgentCoreApp()

def create_visualization(data_str):
    # Convert string data to DataFrame
    df = pd.read_csv(io.StringIO(data_str))
    
    # Create visualization
    plt.figure(figsize=(10, 6))
    df.plot()
    plt.title("Data Visualization")
    
    # Convert plot to base64 string
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    img_str = base64.b64encode(buf.read()).decode()
    plt.close()
    
    return img_str

def analyze_data(data_str):
    df = pd.read_csv(io.StringIO(data_str))
    analysis = {
        "summary": df.describe().to_string(),
        "correlations": df.corr().to_string(),
        "missing_values": df.isnull().sum().to_string()
    }
    return analysis

# Initialize agent with data analysis capabilities
agent = Agent(tools=[
    AWebBrowserTool(),
])

# Add data analysis system prompt
agent.update_system_prompt("""
You are a specialized data analysis assistant skilled in:
- Processing and analyzing CSV data
- Creating visualizations using matplotlib
- Performing statistical analysis using pandas
- Generating detailed analytical reports

When working with data:
1. First examine the data structure and content
2. Perform appropriate statistical analysis
3. Create relevant visualizations
4. Provide clear explanations of findings

You can handle tasks like:
- Data cleaning and preprocessing
- Statistical analysis and hypothesis testing
- Trend identification and pattern recognition
- Correlation analysis
- Data visualization and reporting
""")



class HandlerRequest(BaseModel):
    prompt: str

class HandlerResponse(BaseModel):
    statusCode: int
    result: str

@app.entrypoint
def handler(evt) -> HandlerResponse:
    # Create a session manager that stores data in S3
    logger.info(f"handler received request {evt}, type {type(evt)}")
    request = evt
    if isinstance(request, dict):
        # not sure why it was coming in as a dict...
        logger.info(f"Converting request to HandlerRequest")
        request = HandlerRequest(prompt=request['prompt'])
        logger.info(f"Type is now {type(request)}")
    logger.info(f"Handler got request {request}")
    result = agent(request.prompt, session_id=uuid4().hex)
    logger.info(f"returning result {result}, type {type(result)}, str {str(result)}, dict {result.__dict__}")
    response_text = result.message['content'][0]['text']
    return HandlerResponse(
        statusCode=200,
        result=response_text
    ).__dict__

if __name__ == "__main__":
    logger.info('starting app')
    app.run()
    logger.info('exiting')
