
import os
import logging
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io
import base64
from pydantic import BaseModel
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent
from strands.session.s3_session_manager import S3SessionManager
from typing import Optional, List, Dict, Any
from uuid import uuid4


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Environment: {os.environ}")

app = BedrockAgentCoreApp()
agent = Agent()



class DataAnalysisRequest(BaseModel):
    prompt: str
    data_path: Optional[str] = None
    analysis_type: Optional[str] = None
    visualization_type: Optional[str] = None

class DataAnalysisResponse(BaseModel):
    statusCode: int
    result: str
    visualizations: Optional[List[str]] = None
    statistics: Optional[Dict[str, Any]] = None



@app.entrypoint
def handler(evt) -> DataAnalysisResponse:
    logger.info(f"handler received request {evt}, type {type(evt)}")
    request = evt
    if isinstance(request, dict):
        logger.info(f"Converting request to DataAnalysisRequest")
        request = DataAnalysisRequest(**request)
        logger.info(f"Type is now {type(request)}")
    
    session_id = uuid4().hex
    result = agent(request.prompt, session_id=session_id)
    
    visualizations = []
    statistics = {}
    
    try:
        if request.data_path:
            df = pd.read_csv(request.data_path)
            
            # Generate basic statistics
            statistics = {
                "summary": df.describe().to_dict(),
                "columns": list(df.columns),
                "shape": df.shape
            }
            
            # Create visualizations based on data type
            plt.figure(figsize=(10, 6))
            if request.visualization_type == "histogram":
                for col in df.select_dtypes(include=['float64', 'int64']).columns:
                    plt.hist(df[col], bins=30)
                    plt.title(f'Histogram of {col}')
                    plt.xlabel(col)
                    plt.ylabel('Frequency')
                    
                    buf = io.BytesIO()
                    plt.savefig(buf, format='png')
                    buf.seek(0)
                    visualizations.append(base64.b64encode(buf.read()).decode())
                    plt.clf()
            
            elif request.visualization_type == "correlation":
                sns.heatmap(df.corr(), annot=True)
                plt.title('Correlation Matrix')
                
                buf = io.BytesIO()
                plt.savefig(buf, format='png')
                buf.seek(0)
                visualizations.append(base64.b64encode(buf.read()).decode())
                plt.clf()
    
    except Exception as e:
        logger.error(f"Error processing data: {str(e)}")
        
    response_text = result.message['content'][0]['text']
    
    return DataAnalysisResponse(
        statusCode=200,
        result=response_text,
        visualizations=visualizations if visualizations else None,
        statistics=statistics if statistics else None
    ).__dict__


if __name__ == "__main__":
    logger.info('starting app')
    app.run()
    logger.info('exiting')
