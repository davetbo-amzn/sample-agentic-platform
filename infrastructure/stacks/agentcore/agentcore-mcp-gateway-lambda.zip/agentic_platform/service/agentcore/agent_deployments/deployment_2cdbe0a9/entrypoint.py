import os
import logging
from pydantic import BaseModel
from bedrock_agentcore.runtime import BedrockAgentCoreApp

from strands import Agent
from strands.session.s3_session_manager import S3SessionManager
from strands.tools import agentic_web_browser_tool
from uuid import uuid4

AWS_DOCS_URL = "https://docs.aws.amazon.com/"


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Environment: {os.environ}")

app = BedrockAgentCoreApp()

agent = Agent(tools=[agentic_web_browser_tool], 
             system_prompt="""You are an expert AWS cloud architect and developer assistant. Your role is to:
             1. Answer questions about AWS services accurately and comprehensively
             2. Provide code examples and implementation guidance
             3. Help troubleshoot AWS-related issues
             4. Recommend best practices for cloud architecture
             5. Reference official AWS documentation when needed using the web browser tool
             
             Always strive to provide practical, security-conscious advice that follows AWS Well-Architected Framework principles.""")



class HandlerRequest(BaseModel):
    prompt: str

class HandlerResponse(BaseModel):
    statusCode: int
    result: str

@app.entrypoint
def handler(evt) -> HandlerResponse:
    # Create a session manager that stores data in S3
    logger.info(f"handler received request {evt}, type {type(evt)}")
    request = evt
    if isinstance(request, dict):
        # not sure why it was coming in as a dict...
        logger.info(f"Converting request to HandlerRequest")
        request = HandlerRequest(prompt=request['prompt'])
        logger.info(f"Type is now {type(request)}")
    logger.info(f"Handler got request {request}")
    result = agent(request.prompt, session_id=uuid4().hex)
    logger.info(f"returning result {result}, type {type(result)}, str {str(result)}, dict {result.__dict__}")
    response_text = result.message['content'][0]['text']
    return HandlerResponse(
        statusCode=200,
        result=response_text
    ).__dict__

if __name__ == "__main__":
    logger.info('starting app')
    app.run()
    logger.info('exiting')
