import os
import logging

from pydantic import BaseModel
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from strands import Agent
from strands.session.s3_session_manager import S3SessionManager
from strands.tools import agentic_web_browser_tool
import pandas as pd
import matplotlib.pyplot as plt
import io
import base64
from uuid import uuid4


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info(f"Environment: {os.environ}")


app = BedrockAgentCoreApp()
agent = Agent(tools=[agentic_web_browser_tool])

def generate_visualization(df, analysis_type):
    plt.figure(figsize=(10, 6))
    if analysis_type == "histogram":
        df.hist()
    elif analysis_type == "boxplot":
        df.boxplot()
    elif analysis_type == "correlation":
        pd.plotting.scatter_matrix(df)
    else:
        df.plot()
    
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode()




class HandlerRequest(BaseModel):
    prompt: str
    data_url: str = None
    analysis_type: str = None

class HandlerResponse(BaseModel):
    statusCode: int
    result: str
    visualization: str = None
    statistics: dict = None


@app.entrypoint
def handler(evt) -> HandlerResponse:
    # Create a session manager that stores data in S3
    logger.info(f"handler received request {evt}, type {type(evt)}")
    request = evt
    if isinstance(request, dict):
        # not sure why it was coming in as a dict...
        logger.info(f"Converting request to HandlerRequest")
        request = HandlerRequest(prompt=request['prompt'])
        logger.info(f"Type is now {type(request)}")
    logger.info(f"Handler got request {request}")
    
    session_id = uuid4().hex
    result = agent(request.prompt, session_id=session_id)
    
    response_text = result.message['content'][0]['text']
    visualization = None
    statistics = None
    
    if request.data_url:
        try:
            df = pd.read_csv(request.data_url)
            
            # Generate basic statistics
            statistics = {
                "summary": df.describe().to_dict(),
                "columns": list(df.columns),
                "shape": df.shape
            }
            
            # Generate visualization if requested
            if request.analysis_type:
                visualization = generate_visualization(df, request.analysis_type)
                
        except Exception as e:
            logger.error(f"Error processing data: {str(e)}")
            
    return HandlerResponse(
        statusCode=200,
        result=response_text,
        visualization=visualization,
        statistics=statistics
    ).__dict__


if __name__ == "__main__":
    logger.info('starting app')
    app.run()
    logger.info('exiting')
